"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Loader2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useToast } from "@/components/ui/use-toast"

interface TwoFactorAuthProps {
  onVerify: () => void
  onCancel: () => void
  phoneNumber?: string
  email?: string
}

export function TwoFactorAuth({ onVerify, onCancel, phoneNumber, email }: TwoFactorAuthProps) {
  const [otpValues, setOtpValues] = useState<string[]>(["", "", "", "", "", ""])
  const [isLoading, setIsLoading] = useState(false)
  const [timeLeft, setTimeLeft] = useState(60)
  const [method, setMethod] = useState<"sms" | "email">("sms")
  const inputRefs = useRef<(HTMLInputElement | null)[]>([])
  const { toast } = useToast()

  // Timer countdown
  useEffect(() => {
    if (timeLeft <= 0) return

    const timer = setTimeout(() => {
      setTimeLeft(timeLeft - 1)
    }, 1000)

    return () => clearTimeout(timer)
  }, [timeLeft])

  // Format display of contact method
  const formatContact = () => {
    if (method === "sms" && phoneNumber) {
      // Show only last 4 digits
      return `${phoneNumber.slice(0, -4).replace(/./g, "*")}${phoneNumber.slice(-4)}`
    } else if (method === "email" && email) {
      // Show first 2 chars and domain, hide the rest
      const [username, domain] = email.split("@")
      return `${username.slice(0, 2)}${"*".repeat(username.length - 2)}@${domain}`
    }
    return ""
  }

  const handleInputChange = (index: number, value: string) => {
    // Only allow numbers
    if (!/^\d*$/.test(value)) return

    const newOtpValues = [...otpValues]
    newOtpValues[index] = value

    setOtpValues(newOtpValues)

    // Auto-focus next input
    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus()
    }
  }

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    // Move to previous input on backspace if current input is empty
    if (e.key === "Backspace" && !otpValues[index] && index > 0) {
      inputRefs.current[index - 1]?.focus()
    }
  }

  const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault()
    const pastedData = e.clipboardData.getData("text")

    // Check if pasted content is a 6-digit number
    if (/^\d{6}$/.test(pastedData)) {
      const digits = pastedData.split("")
      setOtpValues(digits)

      // Focus the last input
      inputRefs.current[5]?.focus()
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    const otp = otpValues.join("")

    // Validate OTP
    if (otp.length !== 6) {
      toast({
        title: "Kode OTP tidak valid",
        description: "Silakan masukkan 6 digit kode OTP",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      // Simulate API call to verify OTP
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // For demo purposes, any 6-digit code is accepted
      onVerify()

      toast({
        title: "Verifikasi berhasil",
        description: "Anda telah berhasil memverifikasi akun",
      })
    } catch (error) {
      toast({
        title: "Verifikasi gagal",
        description: "Kode OTP tidak valid atau telah kedaluwarsa",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleResendCode = async () => {
    setIsLoading(true)

    try {
      // Simulate API call to resend OTP
      await new Promise((resolve) => setTimeout(resolve, 1000))

      setTimeLeft(60)

      toast({
        title: "Kode OTP terkirim",
        description: `Kode OTP baru telah dikirim ke ${method === "sms" ? "nomor telepon" : "email"} Anda`,
      })
    } catch (error) {
      toast({
        title: "Gagal mengirim kode OTP",
        description: "Silakan coba lagi nanti",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const toggleMethod = () => {
    setMethod(method === "sms" ? "email" : "sms")
  }

  return (
    <div className="max-w-md mx-auto p-6 bg-white rounded-lg shadow-md">
      <h2 className="text-2xl font-bold text-center mb-6">Verifikasi Dua Faktor</h2>

      <p className="text-center text-gray-600 mb-6">
        Kami telah mengirimkan kode verifikasi ke {method === "sms" ? "nomor telepon" : "email"} Anda {formatContact()}
      </p>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="flex justify-center gap-2">
          {otpValues.map((value, index) => (
            <Input
              key={index}
              ref={(el) => (inputRefs.current[index] = el)}
              type="text"
              inputMode="numeric"
              maxLength={1}
              value={value}
              onChange={(e) => handleInputChange(index, e.target.value)}
              onKeyDown={(e) => handleKeyDown(index, e)}
              onPaste={index === 0 ? handlePaste : undefined}
              className="w-12 h-12 text-center text-xl font-bold"
              disabled={isLoading}
              autoFocus={index === 0}
            />
          ))}
        </div>

        <div className="text-center">
          <p className="text-sm text-gray-500 mb-2">
            Tidak menerima kode? {timeLeft > 0 ? `Kirim ulang dalam ${timeLeft}s` : ""}
          </p>

          <div className="flex flex-col sm:flex-row justify-center gap-2 text-sm">
            {timeLeft <= 0 && (
              <Button
                type="button"
                variant="link"
                onClick={handleResendCode}
                disabled={isLoading || timeLeft > 0}
                className="text-orange-500 hover:text-orange-600"
              >
                Kirim Ulang Kode
              </Button>
            )}

            <Button
              type="button"
              variant="link"
              onClick={toggleMethod}
              disabled={isLoading}
              className="text-orange-500 hover:text-orange-600"
            >
              Gunakan {method === "sms" ? "Email" : "SMS"}
            </Button>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <Button type="button" variant="outline" onClick={onCancel} disabled={isLoading} className="flex-1">
            Batalkan
          </Button>

          <Button
            type="submit"
            disabled={isLoading || otpValues.some((v) => !v)}
            className="flex-1 bg-orange-500 hover:bg-orange-600"
          >
            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Verifikasi
          </Button>
        </div>
      </form>
    </div>
  )
}

