import { create } from "zustand"
import { persist } from "zustand/middleware"

export type OrderStatus = "pending_payment" | "processing" | "shipped" | "delivered" | "cancelled" | "refunded"

export type DeliveryOption = "same_day" | "next_day" | "regular" | "custom_date"

export interface OrderItem {
  id: number
  productId: number
  name: string
  price: number
  quantity: number
  image: string
  customizations?: Record<string, any>
}

export interface Order {
  id: string
  userId: string
  items: OrderItem[]
  status: OrderStatus
  totalAmount: number
  shippingFee: number
  discount: number
  paymentMethod: string
  paymentStatus: "pending" | "paid" | "failed"
  shippingAddress: {
    recipient: string
    phone: string
    address: string
    city: string
    postalCode: string
  }
  deliveryOption: DeliveryOption
  deliveryDate?: string
  trackingNumber?: string
  trackingEvents?: {
    status: string
    timestamp: string
    description: string
  }[]
  notes?: string
  createdAt: string
  updatedAt: string
}

interface OrderState {
  orders: Order[]
  activeOrder: Order | null
  addOrder: (order: Omit<Order, "id" | "createdAt" | "updatedAt">) => string
  updateOrderStatus: (id: string, status: OrderStatus) => void
  cancelOrder: (id: string, reason: string) => void
  getOrderById: (id: string) => Order | undefined
  getOrdersByUserId: (userId: string) => Order[]
  setActiveOrder: (order: Order | null) => void
}

export const useOrders = create<OrderState>()(
  persist(
    (set, get) => ({
      orders: [],
      activeOrder: null,

      addOrder: (orderData) => {
        const id = Math.random().toString(36).substr(2, 9)
        const now = new Date().toISOString()

        const newOrder: Order = {
          id,
          ...orderData,
          createdAt: now,
          updatedAt: now,
        }

        set((state) => ({
          orders: [...state.orders, newOrder],
        }))

        return id
      },

      updateOrderStatus: (id, status) => {
        set((state) => ({
          orders: state.orders.map((order) =>
            order.id === id
              ? {
                  ...order,
                  status,
                  updatedAt: new Date().toISOString(),
                  trackingEvents: [
                    ...(order.trackingEvents || []),
                    {
                      status,
                      timestamp: new Date().toISOString(),
                      description: `Order status updated to ${status}`,
                    },
                  ],
                }
              : order,
          ),
        }))
      },

      cancelOrder: (id, reason) => {
        set((state) => ({
          orders: state.orders.map((order) =>
            order.id === id
              ? {
                  ...order,
                  status: "cancelled",
                  updatedAt: new Date().toISOString(),
                  trackingEvents: [
                    ...(order.trackingEvents || []),
                    {
                      status: "cancelled",
                      timestamp: new Date().toISOString(),
                      description: `Order cancelled: ${reason}`,
                    },
                  ],
                }
              : order,
          ),
        }))
      },

      getOrderById: (id) => {
        return get().orders.find((order) => order.id === id)
      },

      getOrdersByUserId: (userId) => {
        return get().orders.filter((order) => order.userId === userId)
      },

      setActiveOrder: (order) => {
        set({ activeOrder: order })
      },
    }),
    {
      name: "orders-storage",
    },
  ),
)

