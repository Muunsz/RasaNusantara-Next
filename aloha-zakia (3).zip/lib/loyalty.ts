import { create } from "zustand"
import { persist } from "zustand/middleware"

export type MembershipLevel = "bronze" | "silver" | "gold" | "platinum"

export interface Reward {
  id: string
  name: string
  description: string
  pointCost: number
  type: "discount" | "free_item" | "free_shipping" | "cashback"
  value: number
  expiryDate?: string
  image?: string
}

export interface Voucher {
  id: string
  code: string
  name: string
  description: string
  type: "percentage" | "fixed" | "free_shipping"
  value: number
  minPurchase: number
  maxDiscount?: number
  expiryDate: string
  isUsed: boolean
}

interface LoyaltyState {
  points: number
  level: MembershipLevel
  totalSpent: number
  availableRewards: Reward[]
  claimedRewards: Reward[]
  vouchers: Voucher[]
  referralCode: string
  referralCount: number
  addPoints: (points: number) => void
  deductPoints: (points: number) => boolean
  updateLevel: (level: MembershipLevel) => void
  addTotalSpent: (amount: number) => void
  claimReward: (rewardId: string) => boolean
  addVoucher: (voucher: Omit<Voucher, "id" | "isUsed">) => void
  useVoucher: (voucherId: string) => boolean
  getLevelRequirements: () => {
    currentLevel: MembershipLevel
    nextLevel: MembershipLevel | null
    pointsToNextLevel: number
  }
}

const LEVEL_THRESHOLDS = {
  bronze: 0,
  silver: 1000000,
  gold: 5000000,
  platinum: 15000000,
}

export const useLoyalty = create<LoyaltyState>()(
  persist(
    (set, get) => ({
      points: 0,
      level: "bronze",
      totalSpent: 0,
      availableRewards: [
        {
          id: "1",
          name: "Diskon 10%",
          description: "Diskon 10% untuk pembelian berikutnya",
          pointCost: 100,
          type: "discount",
          value: 10,
          expiryDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
          image: "/placeholder.svg?height=100&width=100",
        },
        {
          id: "2",
          name: "Gratis Ongkir",
          description: "Gratis ongkir untuk pembelian berikutnya",
          pointCost: 200,
          type: "free_shipping",
          value: 0,
          expiryDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
          image: "/placeholder.svg?height=100&width=100",
        },
        {
          id: "3",
          name: "Cashback Rp50.000",
          description: "Cashback Rp50.000 untuk pembelian minimum Rp500.000",
          pointCost: 500,
          type: "cashback",
          value: 50000,
          expiryDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
          image: "/placeholder.svg?height=100&width=100",
        },
      ],
      claimedRewards: [],
      vouchers: [],
      referralCode: "REFNUSANTARA123",
      referralCount: 0,

      addPoints: (points) => {
        set((state) => ({ points: state.points + points }))
      },

      deductPoints: (points) => {
        const currentPoints = get().points
        if (currentPoints >= points) {
          set({ points: currentPoints - points })
          return true
        }
        return false
      },

      updateLevel: (level) => {
        set({ level })
      },

      addTotalSpent: (amount) => {
        const newTotalSpent = get().totalSpent + amount
        set({ totalSpent: newTotalSpent })

        // Automatically update level based on total spent
        let newLevel: MembershipLevel = "bronze"

        if (newTotalSpent >= LEVEL_THRESHOLDS.platinum) {
          newLevel = "platinum"
        } else if (newTotalSpent >= LEVEL_THRESHOLDS.gold) {
          newLevel = "gold"
        } else if (newTotalSpent >= LEVEL_THRESHOLDS.silver) {
          newLevel = "silver"
        }

        if (newLevel !== get().level) {
          set({ level: newLevel })
        }
      },

      claimReward: (rewardId) => {
        const reward = get().availableRewards.find((r) => r.id === rewardId)
        if (!reward) return false

        if (get().points >= reward.pointCost) {
          set((state) => ({
            points: state.points - reward.pointCost,
            claimedRewards: [...state.claimedRewards, reward],
            availableRewards: state.availableRewards.filter((r) => r.id !== rewardId),
          }))
          return true
        }

        return false
      },

      addVoucher: (voucher) => {
        const id = Math.random().toString(36).substr(2, 9)
        set((state) => ({
          vouchers: [...state.vouchers, { ...voucher, id, isUsed: false }],
        }))
      },

      useVoucher: (voucherId) => {
        const voucher = get().vouchers.find((v) => v.id === voucherId)
        if (!voucher || voucher.isUsed) return false

        set((state) => ({
          vouchers: state.vouchers.map((v) => (v.id === voucherId ? { ...v, isUsed: true } : v)),
        }))

        return true
      },

      getLevelRequirements: () => {
        const { level, totalSpent } = get()
        let nextLevel: MembershipLevel | null = null
        let pointsToNextLevel = 0

        if (level === "bronze") {
          nextLevel = "silver"
          pointsToNextLevel = LEVEL_THRESHOLDS.silver - totalSpent
        } else if (level === "silver") {
          nextLevel = "gold"
          pointsToNextLevel = LEVEL_THRESHOLDS.gold - totalSpent
        } else if (level === "gold") {
          nextLevel = "platinum"
          pointsToNextLevel = LEVEL_THRESHOLDS.platinum - totalSpent
        } else {
          nextLevel = null
          pointsToNextLevel = 0
        }

        return { currentLevel: level, nextLevel, pointsToNextLevel }
      },
    }),
    {
      name: "loyalty-storage",
    },
  ),
)

