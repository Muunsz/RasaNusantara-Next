import { create } from "zustand"
import { persist } from "zustand/middleware"

interface User {
  id: string
  name: string
  email: string
  phone?: string
  role: "user" | "admin"
  points: number
  level: "bronze" | "silver" | "gold"
  addresses: Address[]
  preferences: UserPreferences
}

interface Address {
  id: string
  label: string
  recipient: string
  phone: string
  address: string
  city: string
  postalCode: string
  isDefault: boolean
}

interface UserPreferences {
  notifications: {
    email: boolean
    whatsapp: boolean
    push: boolean
  }
  newsletter: boolean
}

interface AuthState {
  user: User | null
  isAuthenticated: boolean
  login: (credentials: { email: string; password: string }) => Promise<void>
  register: (userData: { name: string; email: string; password: string }) => Promise<void>
  logout: () => void
  updateProfile: (data: Partial<User>) => Promise<void>
  addAddress: (address: Omit<Address, "id">) => Promise<void>
  updateAddress: (id: string, address: Partial<Address>) => Promise<void>
  deleteAddress: (id: string) => Promise<void>
  updatePreferences: (preferences: Partial<UserPreferences>) => Promise<void>
}

export const useAuth = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      isAuthenticated: false,

      login: async (credentials) => {
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1000))

        // Mock user data
        const user: User = {
          id: "1",
          name: "John Doe",
          email: credentials.email,
          role: "user",
          points: 100,
          level: "bronze",
          addresses: [],
          preferences: {
            notifications: {
              email: true,
              whatsapp: true,
              push: false,
            },
            newsletter: true,
          },
        }

        set({ user, isAuthenticated: true })
      },

      register: async (userData) => {
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1000))

        const user: User = {
          id: "1",
          ...userData,
          role: "user",
          points: 0,
          level: "bronze",
          addresses: [],
          preferences: {
            notifications: {
              email: true,
              whatsapp: true,
              push: false,
            },
            newsletter: true,
          },
        }

        set({ user, isAuthenticated: true })
      },

      logout: () => {
        set({ user: null, isAuthenticated: false })
      },

      updateProfile: async (data) => {
        const currentUser = get().user
        if (!currentUser) return

        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1000))

        set({ user: { ...currentUser, ...data } })
      },

      addAddress: async (address) => {
        const currentUser = get().user
        if (!currentUser) return

        const newAddress: Address = {
          ...address,
          id: Math.random().toString(36).substr(2, 9),
        }

        set({
          user: {
            ...currentUser,
            addresses: [...currentUser.addresses, newAddress],
          },
        })
      },

      updateAddress: async (id, address) => {
        const currentUser = get().user
        if (!currentUser) return

        set({
          user: {
            ...currentUser,
            addresses: currentUser.addresses.map((addr) => (addr.id === id ? { ...addr, ...address } : addr)),
          },
        })
      },

      deleteAddress: async (id) => {
        const currentUser = get().user
        if (!currentUser) return

        set({
          user: {
            ...currentUser,
            addresses: currentUser.addresses.filter((addr) => addr.id !== id),
          },
        })
      },

      updatePreferences: async (preferences) => {
        const currentUser = get().user
        if (!currentUser) return

        set({
          user: {
            ...currentUser,
            preferences: {
              ...currentUser.preferences,
              ...preferences,
            },
          },
        })
      },
    }),
    {
      name: "auth-storage",
    },
  ),
)

