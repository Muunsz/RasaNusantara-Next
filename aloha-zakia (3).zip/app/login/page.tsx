"use client"

import { useState } from "react"
import Link from "next/link"
import { Facebook, Mail } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { LoginForm } from "@/components/auth/login-form"
import { RegisterForm } from "@/components/auth/register-form"
import { ForgotPasswordForm } from "@/components/auth/forgot-password-form"

export default function LoginPage() {
  const [activeTab, setActiveTab] = useState("login")

  return (
    <div className="container mx-auto px-4 py-16 flex items-center justify-center min-h-[80vh]">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl font-bold text-center">
            {activeTab === "login" && "Masuk ke Akun Anda"}
            {activeTab === "register" && "Daftar Akun Baru"}
            {activeTab === "forgot-password" && "Lupa Password"}
          </CardTitle>
          <CardDescription className="text-center">
            {activeTab === "login" && "Masukkan email dan password Anda untuk login"}
            {activeTab === "register" && "Buat akun baru untuk menikmati fitur lengkap"}
            {activeTab === "forgot-password" && "Masukkan email Anda untuk reset password"}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="login">Login</TabsTrigger>
              <TabsTrigger value="register">Register</TabsTrigger>
            </TabsList>
            <TabsContent value="login">
              <LoginForm />
              <div className="mt-4 text-center">
                <Button
                  variant="link"
                  className="text-sm text-orange-500 hover:text-orange-600"
                  onClick={() => setActiveTab("forgot-password")}
                >
                  Lupa password?
                </Button>
              </div>
            </TabsContent>
            <TabsContent value="register">
              <RegisterForm />
            </TabsContent>
            <TabsContent value="forgot-password">
              <ForgotPasswordForm onBack={() => setActiveTab("login")} />
            </TabsContent>
          </Tabs>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-white px-2 text-gray-500">Atau lanjutkan dengan</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <Button variant="outline" className="w-full">
              <Facebook className="mr-2 h-4 w-4" />
              Facebook
            </Button>
            <Button variant="outline" className="w-full">
              <Mail className="mr-2 h-4 w-4" />
              Google
            </Button>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col">
          <p className="text-center text-sm text-gray-500 mt-2">
            Dengan melanjutkan, Anda menyetujui{" "}
            <Link href="/terms" className="text-orange-500 hover:text-orange-600">
              Syarat & Ketentuan
            </Link>{" "}
            dan{" "}
            <Link href="/privacy" className="text-orange-500 hover:text-orange-600">
              Kebijakan Privasi
            </Link>{" "}
            kami.
          </p>
        </CardFooter>
      </Card>
    </div>
  )
}

