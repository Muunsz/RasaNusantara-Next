"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { ChevronRight, Eye, EyeOff, KeyRound, Smartphone, Mail } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { TwoFactorAuth } from "@/components/two-factor-auth"

export default function SecurityPage() {
  const { toast } = useToast()
  const [currentPassword, setCurrentPassword] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [showCurrentPassword, setShowCurrentPassword] = useState(false)
  const [showNewPassword, setShowNewPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [is2FAEnabled, setIs2FAEnabled] = useState(false)
  const [show2FASetup, setShow2FASetup] = useState(false)

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault()

    if (newPassword !== confirmPassword) {
      toast({
        title: "Password tidak cocok",
        description: "Password baru dan konfirmasi password harus sama",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500))

      toast({
        title: "Password berhasil diubah",
        description: "Password Anda telah berhasil diperbarui",
      })

      // Reset form
      setCurrentPassword("")
      setNewPassword("")
      setConfirmPassword("")
    } catch (error) {
      toast({
        title: "Gagal mengubah password",
        description: "Terjadi kesalahan saat mengubah password",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handle2FAToggle = (checked: boolean) => {
    if (checked) {
      // Show 2FA setup
      setShow2FASetup(true)
    } else {
      // Disable 2FA
      setIs2FAEnabled(false)
      toast({
        title: "Verifikasi Dua Faktor dinonaktifkan",
        description: "Verifikasi Dua Faktor telah dinonaktifkan untuk akun Anda",
      })
    }
  }

  const handle2FAVerified = () => {
    setShow2FASetup(false)
    setIs2FAEnabled(true)
    toast({
      title: "Verifikasi Dua Faktor diaktifkan",
      description: "Verifikasi Dua Faktor telah berhasil diaktifkan untuk akun Anda",
    })
  }

  const handle2FACancel = () => {
    setShow2FASetup(false)
    toast({
      title: "Pengaturan dibatalkan",
      description: "Pengaturan Verifikasi Dua Faktor dibatalkan",
    })
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-orange-800 mb-8">Pengaturan Keamanan</h1>

      {/* Breadcrumbs */}
      <div className="flex items-center text-sm text-gray-500 mb-8">
        <Link href="/" className="hover:text-orange-500">
          Beranda
        </Link>
        <ChevronRight className="h-4 w-4 mx-2" />
        <Link href="/account" className="hover:text-orange-500">
          Akun
        </Link>
        <ChevronRight className="h-4 w-4 mx-2" />
        <span className="text-gray-700">Keamanan</span>
      </div>

      {show2FASetup ? (
        <TwoFactorAuth
          onVerify={handle2FAVerified}
          onCancel={handle2FACancel}
          phoneNumber="+62812****7890"
          email="user@example.com"
        />
      ) : (
        <Tabs defaultValue="password" className="space-y-6">
          <TabsList>
            <TabsTrigger value="password">
              <KeyRound className="h-4 w-4 mr-2" />
              Password
            </TabsTrigger>
            <TabsTrigger value="2fa">
              <Smartphone className="h-4 w-4 mr-2" />
              Verifikasi Dua Faktor
            </TabsTrigger>
          </TabsList>

          <TabsContent value="password">
            <Card>
              <CardHeader>
                <CardTitle>Ubah Password</CardTitle>
                <CardDescription>Ubah password Anda secara berkala untuk meningkatkan keamanan akun</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handlePasswordChange} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="current-password">Password Saat Ini</Label>
                    <div className="relative">
                      <Input
                        id="current-password"
                        type={showCurrentPassword ? "text" : "password"}
                        value={currentPassword}
                        onChange={(e) => setCurrentPassword(e.target.value)}
                        required
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                        onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                      >
                        {showCurrentPassword ? (
                          <EyeOff className="h-4 w-4 text-gray-400" />
                        ) : (
                          <Eye className="h-4 w-4 text-gray-400" />
                        )}
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="new-password">Password Baru</Label>
                    <div className="relative">
                      <Input
                        id="new-password"
                        type={showNewPassword ? "text" : "password"}
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        required
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                        onClick={() => setShowNewPassword(!showNewPassword)}
                      >
                        {showNewPassword ? (
                          <EyeOff className="h-4 w-4 text-gray-400" />
                        ) : (
                          <Eye className="h-4 w-4 text-gray-400" />
                        )}
                      </Button>
                    </div>
                    <p className="text-xs text-gray-500">
                      Password harus terdiri dari minimal 8 karakter, termasuk huruf besar, huruf kecil, angka, dan
                      simbol
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="confirm-password">Konfirmasi Password Baru</Label>
                    <div className="relative">
                      <Input
                        id="confirm-password"
                        type={showConfirmPassword ? "text" : "password"}
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        required
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      >
                        {showConfirmPassword ? (
                          <EyeOff className="h-4 w-4 text-gray-400" />
                        ) : (
                          <Eye className="h-4 w-4 text-gray-400" />
                        )}
                      </Button>
                    </div>
                  </div>

                  <Button type="submit" disabled={isSubmitting}>
                    {isSubmitting ? "Menyimpan..." : "Simpan Perubahan"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="2fa">
            <Card>
              <CardHeader>
                <CardTitle>Verifikasi Dua Faktor (2FA)</CardTitle>
                <CardDescription>Tingkatkan keamanan akun Anda dengan verifikasi dua faktor</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">Verifikasi Dua Faktor</h3>
                    <p className="text-sm text-gray-500">
                      {is2FAEnabled
                        ? "Verifikasi dua faktor saat ini aktif"
                        : "Aktifkan verifikasi dua faktor untuk meningkatkan keamanan akun Anda"}
                    </p>
                  </div>
                  <Switch checked={is2FAEnabled} onCheckedChange={handle2FAToggle} />
                </div>

                {is2FAEnabled && (
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <h4 className="font-medium text-green-800 flex items-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5 mr-2"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                        />
                      </svg>
                      Verifikasi Dua Faktor Aktif
                    </h4>
                    <p className="text-sm text-green-700 mt-2">
                      Akun Anda terlindungi dengan verifikasi dua faktor. Setiap kali login dari perangkat baru, Anda
                      akan diminta memasukkan kode verifikasi.
                    </p>
                  </div>
                )}

                <div className="space-y-4">
                  <h3 className="font-medium">Metode Verifikasi</h3>

                  <div className="border rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Smartphone className="h-5 w-5 text-gray-500 mr-3" />
                        <div>
                          <h4 className="font-medium">SMS</h4>
                          <p className="text-sm text-gray-500">Terima kode verifikasi melalui SMS</p>
                        </div>
                      </div>
                      <input
                        type="radio"
                        name="verification-method"
                        checked
                        className="text-orange-500 focus:ring-orange-500"
                        readOnly
                      />
                    </div>
                  </div>

                  <div className="border rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Mail className="h-5 w-5 text-gray-500 mr-3" />
                        <div>
                          <h4 className="font-medium">Email</h4>
                          <p className="text-sm text-gray-500">Terima kode verifikasi melalui email</p>
                        </div>
                      </div>
                      <input
                        type="radio"
                        name="verification-method"
                        className="text-orange-500 focus:ring-orange-500"
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}
    </div>
  )
}

