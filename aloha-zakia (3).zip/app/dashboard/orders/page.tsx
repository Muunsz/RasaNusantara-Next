"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { format } from "date-fns"
import { id } from "date-fns/locale"
import { AlertCircle, CheckCircle, Clock, Package, Truck, XCircle } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { useAuth } from "@/lib/auth"
import { useOrders, type Order, type OrderStatus } from "@/lib/orders"

export default function OrdersPage() {
  const router = useRouter()
  const { user, isAuthenticated } = useAuth()
  const { orders } = useOrders()
  const [userOrders, setUserOrders] = useState<Order[]>([])
  const [activeTab, setActiveTab] = useState("all")

  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/login")
    }
  }, [isAuthenticated, router])

  useEffect(() => {
    if (user) {
      // In a real app, we would fetch orders from API
      // For now, we'll use mock data
      setUserOrders(orders)
    }
  }, [user, orders])

  const filteredOrders = userOrders.filter((order) => {
    if (activeTab === "all") return true
    if (activeTab === "active") return ["pending_payment", "processing", "shipped"].includes(order.status)
    if (activeTab === "completed") return order.status === "delivered"
    if (activeTab === "cancelled") return ["cancelled", "refunded"].includes(order.status)
    return true
  })

  const getStatusIcon = (status: OrderStatus) => {
    switch (status) {
      case "pending_payment":
        return <Clock className="h-5 w-5 text-yellow-500" />
      case "processing":
        return <Package className="h-5 w-5 text-blue-500" />
      case "shipped":
        return <Truck className="h-5 w-5 text-purple-500" />
      case "delivered":
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case "cancelled":
        return <XCircle className="h-5 w-5 text-red-500" />
      case "refunded":
        return <AlertCircle className="h-5 w-5 text-orange-500" />
      default:
        return <Clock className="h-5 w-5 text-gray-500" />
    }
  }

  const getStatusText = (status: OrderStatus) => {
    switch (status) {
      case "pending_payment":
        return "Menunggu Pembayaran"
      case "processing":
        return "Diproses"
      case "shipped":
        return "Dikirim"
      case "delivered":
        return "Diterima"
      case "cancelled":
        return "Dibatalkan"
      case "refunded":
        return "Dikembalikan"
      default:
        return status
    }
  }

  const getStatusColor = (status: OrderStatus) => {
    switch (status) {
      case "pending_payment":
        return "bg-yellow-100 text-yellow-800"
      case "processing":
        return "bg-blue-100 text-blue-800"
      case "shipped":
        return "bg-purple-100 text-purple-800"
      case "delivered":
        return "bg-green-100 text-green-800"
      case "cancelled":
        return "bg-red-100 text-red-800"
      case "refunded":
        return "bg-orange-100 text-orange-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  if (!user) {
    return null
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-orange-800 mb-8">Pesanan Saya</h1>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="all">Semua</TabsTrigger>
          <TabsTrigger value="active">Aktif</TabsTrigger>
          <TabsTrigger value="completed">Selesai</TabsTrigger>
          <TabsTrigger value="cancelled">Dibatalkan</TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="space-y-4">
          {filteredOrders.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Package className="h-12 w-12 text-gray-300 mb-4" />
                <h3 className="text-lg font-medium text-gray-900">Belum ada pesanan</h3>
                <p className="text-gray-500 mt-2">Pesanan Anda akan muncul di sini</p>
                <Button className="mt-4" onClick={() => router.push("/products")}>
                  Mulai Belanja
                </Button>
              </CardContent>
            </Card>
          ) : (
            filteredOrders.map((order) => (
              <Card key={order.id} className="overflow-hidden">
                <CardHeader className="bg-gray-50 pb-4">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div>
                      <CardTitle className="text-lg">Pesanan #{order.id.substring(0, 8)}</CardTitle>
                      <CardDescription>
                        {format(new Date(order.createdAt), "dd MMMM yyyy, HH:mm", { locale: id })}
                      </CardDescription>
                    </div>
                    <div className="flex items-center gap-2">
                      {getStatusIcon(order.status)}
                      <Badge className={getStatusColor(order.status)}>{getStatusText(order.status)}</Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    {order.items.map((item) => (
                      <div key={item.id} className="flex gap-4">
                        <div className="relative h-16 w-16 rounded-md overflow-hidden flex-shrink-0">
                          <Image src={item.image || "/placeholder.svg"} alt={item.name} fill className="object-cover" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-medium">{item.name}</h3>
                          <p className="text-sm text-gray-500">
                            {item.quantity} x Rp {item.price.toLocaleString()}
                          </p>
                          {item.customizations && (
                            <p className="text-xs text-gray-500 mt-1">
                              Kustomisasi:{" "}
                              {Object.entries(item.customizations)
                                .map(([key, value]) => `${key}: ${value}`)
                                .join(", ")}
                            </p>
                          )}
                        </div>
                        <div className="text-right">
                          <p className="font-medium">Rp {(item.price * item.quantity).toLocaleString()}</p>
                        </div>
                      </div>
                    ))}

                    <div className="border-t pt-4 mt-4">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-500">Subtotal</span>
                        <span>Rp {order.totalAmount.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between text-sm mt-1">
                        <span className="text-gray-500">Pengiriman</span>
                        <span>Rp {order.shippingFee.toLocaleString()}</span>
                      </div>
                      {order.discount > 0 && (
                        <div className="flex justify-between text-sm mt-1">
                          <span className="text-gray-500">Diskon</span>
                          <span className="text-green-600">-Rp {order.discount.toLocaleString()}</span>
                        </div>
                      )}
                      <div className="flex justify-between font-medium mt-2">
                        <span>Total</span>
                        <span className="text-orange-600">
                          Rp {(order.totalAmount + order.shippingFee - order.discount).toLocaleString()}
                        </span>
                      </div>
                    </div>

                    <div className="border-t pt-4 mt-4">
                      <h4 className="font-medium mb-2">Informasi Pengiriman</h4>
                      <div className="text-sm text-gray-600">
                        <p>{order.shippingAddress.recipient}</p>
                        <p>{order.shippingAddress.phone}</p>
                        <p>{order.shippingAddress.address}</p>
                        <p>
                          {order.shippingAddress.city}, {order.shippingAddress.postalCode}
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={() => router.push(`/dashboard/orders/${order.id}`)}>
                        Detail Pesanan
                      </Button>

                      {order.status === "pending_payment" && (
                        <Button size="sm" className="bg-orange-500 hover:bg-orange-600">
                          Bayar Sekarang
                        </Button>
                      )}

                      {order.status === "delivered" && (
                        <Button size="sm" variant="outline">
                          Beri Ulasan
                        </Button>
                      )}

                      {["pending_payment", "processing"].includes(order.status) && (
                        <Button size="sm" variant="outline" className="text-red-500">
                          Batalkan
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}

