"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { format } from "date-fns"
import { id } from "date-fns/locale"
import { ChevronLeft } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { useAuth } from "@/lib/auth"
import { useOrders, type Order, type OrderStatus } from "@/lib/orders"

export default function OrderDetailPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const { user, isAuthenticated } = useAuth()
  const { getOrderById } = useOrders()
  const [order, setOrder] = useState<Order | null>(null)

  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/login")
    }
  }, [isAuthenticated, router])

  useEffect(() => {
    const orderData = getOrderById(params.id)
    if (orderData) {
      setOrder(orderData)
    } else {
      router.push("/dashboard/orders")
    }
  }, [params.id, getOrderById, router])

  const getStatusColor = (status: OrderStatus) => {
    switch (status) {
      case "pending_payment":
        return "bg-yellow-100 text-yellow-800"
      case "processing":
        return "bg-blue-100 text-blue-800"
      case "shipped":
        return "bg-purple-100 text-purple-800"
      case "delivered":
        return "bg-green-100 text-green-800"
      case "cancelled":
        return "bg-red-100 text-red-800"
      case "refunded":
        return "bg-orange-100 text-orange-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusText = (status: OrderStatus) => {
    switch (status) {
      case "pending_payment":
        return "Menunggu Pembayaran"
      case "processing":
        return "Diproses"
      case "shipped":
        return "Dikirim"
      case "delivered":
        return "Diterima"
      case "cancelled":
        return "Dibatalkan"
      case "refunded":
        return "Dikembalikan"
      default:
        return status
    }
  }

  if (!user || !order) {
    return null
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center mb-8">
        <Button variant="ghost" onClick={() => router.push("/dashboard/orders")} className="mr-4">
          <ChevronLeft className="h-4 w-4 mr-2" />
          Kembali
        </Button>
        <h1 className="text-2xl font-bold text-orange-800">Detail Pesanan #{order.id.substring(0, 8)}</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader className="bg-gray-50">
              <div className="flex justify-between items-center">
                <CardTitle className="text-lg">Status Pesanan</CardTitle>
                <Badge className={getStatusColor(order.status)}>{getStatusText(order.status)}</Badge>
              </div>
            </CardHeader>
            <CardContent className="p-6">
              <div className="relative">
                <div className="flex justify-between mb-2">
                  <div className="text-center">
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center mx-auto ${
                        order.status !== "cancelled" ? "bg-green-100 text-green-600" : "bg-gray-100 text-gray-400"
                      }`}
                    >
                      <svg
                        className="w-6 h-6"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"
                        />
                      </svg>
                    </div>
                    <p className="text-sm mt-1">Pesanan Dibuat</p>
                  </div>

                  <div className="text-center">
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center mx-auto ${
                        ["processing", "shipped", "delivered"].includes(order.status)
                          ? "bg-green-100 text-green-600"
                          : "bg-gray-100 text-gray-400"
                      }`}
                    >
                      <svg
                        className="w-6 h-6"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <p className="text-sm mt-1">Diproses</p>
                  </div>

                  <div className="text-center">
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center mx-auto ${
                        ["shipped", "delivered"].includes(order.status)
                          ? "bg-green-100 text-green-600"
                          : "bg-gray-100 text-gray-400"
                      }`}
                    >
                      <svg
                        className="w-6 h-6"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"
                        />
                      </svg>
                    </div>
                    <p className="text-sm mt-1">Dikirim</p>
                  </div>

                  <div className="text-center">
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center mx-auto ${
                        order.status === "delivered" ? "bg-green-100 text-green-600" : "bg-gray-100 text-gray-400"
                      }`}
                    >
                      <svg
                        className="w-6 h-6"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <p className="text-sm mt-1">Diterima</p>
                  </div>
                </div>

                <div className="absolute top-5 left-0 right-0 h-1 bg-gray-200">
                  <div
                    className="h-full bg-green-500"
                    style={{
                      width:
                        order.status === "cancelled"
                          ? "0%"
                          : order.status === "pending_payment"
                            ? "25%"
                            : order.status === "processing"
                              ? "50%"
                              : order.status === "shipped"
                                ? "75%"
                                : "100%",
                    }}
                  />
                </div>
              </div>

              {order.trackingEvents && order.trackingEvents.length > 0 && (
                <div className="mt-8">
                  <h3 className="font-medium mb-4">Riwayat Status</h3>
                  <div className="space-y-4">
                    {order.trackingEvents.map((event, index) => (
                      <div key={index} className="flex">
                        <div className="mr-4 relative">
                          <div className="w-3 h-3 rounded-full bg-orange-500 mt-1.5" />
                          {index < order.trackingEvents!.length - 1 && (
                            <div className="absolute top-3 bottom-0 left-1.5 w-0.5 -ml-px bg-gray-200" />
                          )}
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">{event.description}</p>
                          <p className="text-sm text-gray-500">
                            {format(new Date(event.timestamp), "dd MMMM yyyy, HH:mm", { locale: id })}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Produk yang Dibeli</CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-4">
                {order.items.map((item) => (
                  <div key={item.id} className="flex gap-4">
                    <div className="relative h-20 w-20 rounded-md overflow-hidden flex-shrink-0">
                      <Image src={item.image || "/placeholder.svg"} alt={item.name} fill className="object-cover" />
                    </div>
                    <div className="flex-1">
                      <Link href={`/product/${item.productId}`} className="font-medium hover:text-orange-500">
                        {item.name}
                      </Link>
                      <p className="text-sm text-gray-500">
                        {item.quantity} x Rp {item.price.toLocaleString()}
                      </p>
                      {item.customizations && (
                        <p className="text-xs text-gray-500 mt-1">
                          Kustomisasi:{" "}
                          {Object.entries(item.customizations)
                            .map(([key, value]) => `${key}: ${value}`)
                            .join(", ")}
                        </p>
                      )}
                    </div>
                    <div className="text-right">
                      <p className="font-medium">Rp {(item.price * item.quantity).toLocaleString()}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Ringkasan Pesanan</CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-gray-500 mb-1">Nomor Pesanan</p>
                  <p className="font-medium">{order.id}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 mb-1">Tanggal Pemesanan</p>
                  <p className="font-medium">
                    {format(new Date(order.createdAt), "dd MMMM yyyy, HH:mm", { locale: id })}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 mb-1">Metode Pembayaran</p>
                  <p className="font-medium">{order.paymentMethod}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 mb-1">Status Pembayaran</p>
                  <Badge
                    className={
                      order.paymentStatus === "paid"
                        ? "bg-green-100 text-green-800"
                        : order.paymentStatus === "pending"
                          ? "bg-yellow-100 text-yellow-800"
                          : "bg-red-100 text-red-800"
                    }
                  >
                    {order.paymentStatus === "paid"
                      ? "Dibayar"
                      : order.paymentStatus === "pending"
                        ? "Menunggu Pembayaran"
                        : "Gagal"}
                  </Badge>
                </div>

                <Separator />

                <div>
                  <p className="text-sm text-gray-500 mb-1">Alamat Pengiriman</p>
                  <div className="text-sm">
                    <p className="font-medium">{order.shippingAddress.recipient}</p>
                    <p>{order.shippingAddress.phone}</p>
                    <p>{order.shippingAddress.address}</p>
                    <p>
                      {order.shippingAddress.city}, {order.shippingAddress.postalCode}
                    </p>
                  </div>
                </div>

                <div>
                  <p className="text-sm text-gray-500 mb-1">Opsi Pengiriman</p>
                  <p className="font-medium">
                    {order.deliveryOption === "same_day"
                      ? "Same Day (Hari Ini)"
                      : order.deliveryOption === "next_day"
                        ? "Next Day (Besok)"
                        : order.deliveryOption === "custom_date"
                          ? "Tanggal Tertentu"
                          : "Reguler (2-3 hari)"}
                  </p>
                  {order.deliveryDate && (
                    <p className="text-sm text-gray-500">
                      Tanggal pengiriman: {format(new Date(order.deliveryDate), "dd MMMM yyyy", { locale: id })}
                    </p>
                  )}
                </div>

                {order.trackingNumber && (
                  <div>
                    <p className="text-sm text-gray-500 mb-1">Nomor Resi</p>
                    <p className="font-medium">{order.trackingNumber}</p>
                  </div>
                )}

                <Separator />

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Subtotal</span>
                    <span>Rp {order.totalAmount.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Pengiriman</span>
                    <span>Rp {order.shippingFee.toLocaleString()}</span>
                  </div>
                  {order.discount > 0 && (
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">Diskon</span>
                      <span className="text-green-600">-Rp {order.discount.toLocaleString()}</span>
                    </div>
                  )}
                  <div className="flex justify-between font-medium pt-2 border-t">
                    <span>Total</span>
                    <span className="text-orange-600">
                      Rp {(order.totalAmount + order.shippingFee - order.discount).toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Aksi</CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-3">
                {order.status === "pending_payment" && (
                  <Button className="w-full bg-orange-500 hover:bg-orange-600">Bayar Sekarang</Button>
                )}

                {order.status === "delivered" && <Button className="w-full">Beri Ulasan</Button>}

                {["pending_payment", "processing"].includes(order.status) && (
                  <Button variant="outline" className="w-full text-red-500">
                    Batalkan Pesanan
                  </Button>
                )}

                <Button variant="outline" className="w-full">
                  Hubungi Customer Service
                </Button>

                <Button variant="outline" className="w-full">
                  Unduh Invoice
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

