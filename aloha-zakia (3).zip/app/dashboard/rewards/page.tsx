"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { format } from "date-fns"
import { id } from "date-fns/locale"
import { Award, Gift, Star, Ticket } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/lib/auth"
import { useLoyalty, type MembershipLevel } from "@/lib/loyalty"

export default function RewardsPage() {
  const router = useRouter()
  const { toast } = useToast()
  const { user, isAuthenticated } = useAuth()
  const {
    points,
    level,
    availableRewards,
    claimedRewards,
    vouchers,
    referralCode,
    referralCount,
    claimReward,
    getLevelRequirements,
  } = useLoyalty()

  const { currentLevel, nextLevel, pointsToNextLevel } = getLevelRequirements()

  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/login")
    }
  }, [isAuthenticated, router])

  const getLevelColor = (level: MembershipLevel) => {
    switch (level) {
      case "bronze":
        return "bg-amber-700"
      case "silver":
        return "bg-gray-400"
      case "gold":
        return "bg-yellow-500"
      case "platinum":
        return "bg-purple-600"
      default:
        return "bg-gray-500"
    }
  }

  const getLevelProgress = () => {
    if (!nextLevel) return 100

    const currentThreshold = {
      bronze: 0,
      silver: 1000000,
      gold: 5000000,
      platinum: 15000000,
    }[currentLevel]

    const nextThreshold = {
      bronze: 0,
      silver: 1000000,
      gold: 5000000,
      platinum: 15000000,
    }[nextLevel]

    const totalRange = nextThreshold - currentThreshold
    const progress = totalRange - pointsToNextLevel

    return Math.round((progress / totalRange) * 100)
  }

  const handleClaimReward = (rewardId: string) => {
    const success = claimReward(rewardId)

    if (success) {
      toast({
        title: "Reward berhasil diklaim",
        description: "Silakan cek voucher Anda",
      })
    } else {
      toast({
        title: "Gagal mengklaim reward",
        description: "Poin Anda tidak mencukupi",
        variant: "destructive",
      })
    }
  }

  const copyReferralCode = () => {
    navigator.clipboard.writeText(referralCode)
    toast({
      title: "Kode referral disalin",
      description: "Kode referral telah disalin ke clipboard",
    })
  }

  if (!user) {
    return null
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-orange-800 mb-8">Rewards & Loyalitas</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Poin Anda</CardTitle>
            <CardDescription>Kumpulkan poin untuk mendapatkan reward</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
              <span className="text-3xl font-bold">{points}</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Level Membership</CardTitle>
            <CardDescription>Status keanggotaan Anda</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2 mb-2">
              <div className={`w-6 h-6 rounded-full ${getLevelColor(level)}`}></div>
              <span className="text-xl font-bold capitalize">{level}</span>
            </div>

            {nextLevel && (
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>{currentLevel}</span>
                  <span>{nextLevel}</span>
                </div>
                <Progress value={getLevelProgress()} className="h-2" />
                <p className="text-xs text-gray-500">
                  Belanjakan Rp {pointsToNextLevel.toLocaleString()} lagi untuk mencapai level {nextLevel}
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Kode Referral</CardTitle>
            <CardDescription>Bagikan dan dapatkan poin</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2 mb-2">
              <div className="flex-1 p-2 bg-gray-100 rounded-md font-mono">{referralCode}</div>
              <Button variant="outline" size="sm" onClick={copyReferralCode}>
                Salin
              </Button>
            </div>
            <p className="text-xs text-gray-500">Anda telah mengundang {referralCount} teman</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="rewards" className="space-y-4">
        <TabsList>
          <TabsTrigger value="rewards">
            <Gift className="h-4 w-4 mr-2" />
            Rewards
          </TabsTrigger>
          <TabsTrigger value="vouchers">
            <Ticket className="h-4 w-4 mr-2" />
            Voucher Saya
          </TabsTrigger>
          <TabsTrigger value="benefits">
            <Award className="h-4 w-4 mr-2" />
            Benefit Membership
          </TabsTrigger>
        </TabsList>

        <TabsContent value="rewards" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {availableRewards.map((reward) => (
              <Card key={reward.id}>
                <div className="relative h-40 w-full">
                  <Image
                    src={reward.image || "/placeholder.svg"}
                    alt={reward.name}
                    fill
                    className="object-cover rounded-t-lg"
                  />
                </div>
                <CardHeader>
                  <CardTitle>{reward.name}</CardTitle>
                  <CardDescription>{reward.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      <Star className="h-4 w-4 text-yellow-500 fill-yellow-500 mr-1" />
                      <span className="font-bold">{reward.pointCost} poin</span>
                    </div>
                    {reward.expiryDate && (
                      <span className="text-xs text-gray-500">
                        Berlaku hingga {format(new Date(reward.expiryDate), "dd MMM yyyy", { locale: id })}
                      </span>
                    )}
                  </div>
                </CardContent>
                <CardFooter>
                  <Button
                    className="w-full"
                    disabled={points < reward.pointCost}
                    onClick={() => handleClaimReward(reward.id)}
                  >
                    {points < reward.pointCost ? "Poin Tidak Cukup" : "Tukarkan"}
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="vouchers">
          {vouchers.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Ticket className="h-12 w-12 text-gray-300 mb-4" />
                <h3 className="text-lg font-medium text-gray-900">Belum ada voucher</h3>
                <p className="text-gray-500 mt-2">Tukarkan poin Anda untuk mendapatkan voucher</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {vouchers.map((voucher) => (
                <Card key={voucher.id} className={voucher.isUsed ? "opacity-60" : ""}>
                  <CardHeader className="bg-orange-50 relative">
                    <div className="absolute top-4 right-4">
                      {voucher.isUsed ? (
                        <span className="px-2 py-1 bg-gray-500 text-white text-xs rounded-full">Sudah Digunakan</span>
                      ) : (
                        <span className="px-2 py-1 bg-green-500 text-white text-xs rounded-full">Aktif</span>
                      )}
                    </div>
                    <CardTitle>{voucher.name}</CardTitle>
                    <CardDescription>{voucher.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="p-6">
                    <div className="space-y-4">
                      <div className="flex justify-between">
                        <span className="text-gray-500">Kode Voucher</span>
                        <span className="font-mono font-bold">{voucher.code}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Nilai</span>
                        <span className="font-bold">
                          {voucher.type === "percentage"
                            ? `${voucher.value}%`
                            : voucher.type === "free_shipping"
                              ? "Gratis Ongkir"
                              : `Rp ${voucher.value.toLocaleString()}`}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Min. Pembelian</span>
                        <span>Rp {voucher.minPurchase.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Berlaku Hingga</span>
                        <span>{format(new Date(voucher.expiryDate), "dd MMM yyyy", { locale: id })}</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full" disabled={voucher.isUsed} onClick={() => router.push("/products")}>
                      {voucher.isUsed ? "Sudah Digunakan" : "Gunakan Sekarang"}
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="benefits">
          <Card>
            <CardHeader>
              <CardTitle>Benefit Membership</CardTitle>
              <CardDescription>Nikmati berbagai keuntungan sesuai level membership Anda</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr>
                      <th className="text-left p-2 border-b">Benefit</th>
                      <th className="p-2 border-b bg-amber-50">Bronze</th>
                      <th className="p-2 border-b bg-gray-50">Silver</th>
                      <th className="p-2 border-b bg-yellow-50">Gold</th>
                      <th className="p-2 border-b bg-purple-50">Platinum</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="p-2 border-b">Poin per Rp10.000</td>
                      <td className="p-2 border-b text-center bg-amber-50">1</td>
                      <td className="p-2 border-b text-center bg-gray-50">2</td>
                      <td className="p-2 border-b text-center bg-yellow-50">3</td>
                      <td className="p-2 border-b text-center bg-purple-50">5</td>
                    </tr>
                    <tr>
                      <td className="p-2 border-b">Birthday Reward</td>
                      <td className="p-2 border-b text-center bg-amber-50">-</td>
                      <td className="p-2 border-b text-center bg-gray-50">✓</td>
                      <td className="p-2 border-b text-center bg-yellow-50">✓</td>
                      <td className="p-2 border-b text-center bg-purple-50">✓</td>
                    </tr>
                    <tr>
                      <td className="p-2 border-b">Free Shipping</td>
                      <td className="p-2 border-b text-center bg-amber-50">-</td>
                      <td className="p-2 border-b text-center bg-gray-50">1x/bulan</td>
                      <td className="p-2 border-b text-center bg-yellow-50">3x/bulan</td>
                      <td className="p-2 border-b text-center bg-purple-50">Unlimited</td>
                    </tr>
                    <tr>
                      <td className="p-2 border-b">Exclusive Products</td>
                      <td className="p-2 border-b text-center bg-amber-50">-</td>
                      <td className="p-2 border-b text-center bg-gray-50">-</td>
                      <td className="p-2 border-b text-center bg-yellow-50">✓</td>
                      <td className="p-2 border-b text-center bg-purple-50">✓</td>
                    </tr>
                    <tr>
                      <td className="p-2 border-b">Early Access</td>
                      <td className="p-2 border-b text-center bg-amber-50">-</td>
                      <td className="p-2 border-b text-center bg-gray-50">-</td>
                      <td className="p-2 border-b text-center bg-yellow-50">✓</td>
                      <td className="p-2 border-b text-center bg-purple-50">✓</td>
                    </tr>
                    <tr>
                      <td className="p-2 border-b">Dedicated CS</td>
                      <td className="p-2 border-b text-center bg-amber-50">-</td>
                      <td className="p-2 border-b text-center bg-gray-50">-</td>
                      <td className="p-2 border-b text-center bg-yellow-50">-</td>
                      <td className="p-2 border-b text-center bg-purple-50">✓</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

