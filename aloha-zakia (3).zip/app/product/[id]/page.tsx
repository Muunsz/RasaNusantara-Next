"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { ChevronRight, Heart, Minus, Plus, ShoppingCart, Star } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useCart } from "@/components/cart-provider"
import { RelatedProducts } from "@/components/product/related-products"
import { RecentlyViewed } from "@/components/product/recently-viewed"
import { ProductComparison } from "@/components/product/product-comparison"
import { ARPreview } from "@/components/ar-preview"

// Mock product data - in a real app, this would come from an API
const products = [
  {
    id: 1,
    name: "Bolu Pandan Keju",
    description: "Bolu pandan lembut dengan taburan keju yang melimpah",
    longDescription:
      "Bolu pandan keju kami dibuat dengan bahan-bahan berkualitas tinggi. Menggunakan daun pandan asli untuk aroma yang harum dan keju cheddar premium untuk rasa gurih yang sempurna. Teksturnya yang lembut dan tidak terlalu manis cocok untuk dinikmati bersama teh atau kopi.",
    price: 85000,
    images: [
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
    ],
    category: "bolu",
    isNew: true,
    isBestSeller: false,
    ingredients:
      "Tepung terigu protein sedang, gula pasir, telur ayam, mentega, daun pandan, keju cheddar, baking powder, susu cair.",
    weight: "500 gram",
    dimensions: "20 x 20 x 5 cm",
    storage: "Simpan di tempat sejuk dan kering. Setelah dibuka, simpan di lemari es dan habiskan dalam 3 hari.",
    reviews: [
      {
        id: 1,
        name: "Anisa",
        rating: 5,
        date: "12 Mei 2023",
        comment: "Bolu pandan kejunya lembut dan tidak terlalu manis. Keluarga saya sangat menyukainya!",
      },
      {
        id: 2,
        name: "Budi",
        rating: 4,
        date: "5 Juni 2023",
        comment: "Rasanya enak, tapi saya berharap kejunya lebih banyak. Overall puas dengan produknya.",
      },
    ],
  },
  {
    id: 2,
    name: "Dessert Box Oreo",
    description: "Dessert box dengan lapisan oreo, cream cheese, dan coklat",
    longDescription:
      "Dessert Box Oreo kami adalah perpaduan sempurna antara biskuit oreo yang renyah, cream cheese yang lembut, dan lapisan coklat yang kaya. Setiap suapan memberikan pengalaman rasa yang berbeda dengan tekstur yang bervariasi. Cocok untuk dinikmati sebagai hidangan penutup atau camilan di sore hari.",
    price: 95000,
    images: [
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
    ],
    category: "dessert-box",
    isNew: false,
    isBestSeller: true,
    ingredients: "Biskuit oreo, cream cheese, whipping cream, gula bubuk, dark chocolate, susu cair, gelatin.",
    weight: "350 gram",
    dimensions: "15 x 15 x 8 cm",
    storage: "Simpan di lemari es. Baik dikonsumsi dalam 2-3 hari.",
    reviews: [
      {
        id: 1,
        name: "Diana",
        rating: 5,
        date: "20 April 2023",
        comment: "Dessert box oreonya enak banget! Cream cheesenya pas dan tidak terlalu manis.",
      },
      {
        id: 2,
        name: "Eko",
        rating: 5,
        date: "15 Mei 2023",
        comment: "Saya pesan untuk ulang tahun istri dan dia sangat menyukainya. Akan pesan lagi!",
      },
    ],
  },
]

export default function ProductPage({ params }: { params: { id: string } }) {
  const productId = Number.parseInt(params.id)
  const product = products.find((p) => p.id === productId)

  const [quantity, setQuantity] = useState(1)
  const [selectedImage, setSelectedImage] = useState(0)
  const [showARPreview, setShowARPreview] = useState(false)
  const { addItem } = useCart()

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold mb-4">Produk tidak ditemukan</h1>
        <p className="mb-8">Maaf, produk yang Anda cari tidak tersedia.</p>
        <Button asChild>
          <Link href="/products">Kembali ke Produk</Link>
        </Button>
      </div>
    )
  }

  const decreaseQuantity = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1)
    }
  }

  const increaseQuantity = () => {
    setQuantity(quantity + 1)
  }

  const handleAddToCart = () => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.images[0],
      quantity,
    })
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Breadcrumbs */}
      <div className="flex items-center text-sm text-gray-500 mb-8">
        <Link href="/" className="hover:text-orange-500">
          Beranda
        </Link>
        <ChevronRight className="h-4 w-4 mx-2" />
        <Link href="/products" className="hover:text-orange-500">
          Produk
        </Link>
        <ChevronRight className="h-4 w-4 mx-2" />
        <span className="text-gray-700">{product.name}</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
        {/* Product Images */}
        <div className="space-y-4">
          <div className="relative h-[400px] md:h-[500px] w-full rounded-lg overflow-hidden border">
            <Image
              src={product.images[selectedImage] || "/placeholder.svg"}
              alt={product.name}
              fill
              className="object-cover"
            />
          </div>

          <div className="flex space-x-2 overflow-x-auto pb-2">
            {product.images.map((image, index) => (
              <button
                key={index}
                className={`relative h-20 w-20 rounded-md overflow-hidden border-2 ${
                  selectedImage === index ? "border-orange-500" : "border-transparent"
                }`}
                onClick={() => setSelectedImage(index)}
              >
                <Image
                  src={image || "/placeholder.svg"}
                  alt={`${product.name} thumbnail ${index + 1}`}
                  fill
                  className="object-cover"
                />
              </button>
            ))}
          </div>

          {/* AR Preview Button */}
          <Button variant="outline" onClick={() => setShowARPreview(true)} className="w-full">
            <span className="mr-2">👁️</span>
            Lihat dalam AR
          </Button>

          {/* AR Preview Modal */}
          {showARPreview && (
            <ARPreview
              productImage={product.images[0]}
              productName={product.name}
              onClose={() => setShowARPreview(false)}
            />
          )}
        </div>

        {/* Product Details */}
        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-bold text-orange-800 mb-2">{product.name}</h1>
            <p className="text-gray-600 mb-4">{product.description}</p>
            <div className="flex items-center mb-4">
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className={`h-5 w-5 ${i < 4 ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`} />
                ))}
              </div>
              <span className="text-gray-500 ml-2">(4.0) · {product.reviews.length} ulasan</span>
            </div>
            <p className="text-2xl font-bold text-orange-600">Rp {product.price.toLocaleString()}</p>
          </div>

          <div className="pt-4 border-t border-gray-200">
            <h3 className="font-semibold text-gray-700 mb-2">Jumlah</h3>
            <div className="flex items-center space-x-4">
              <div className="flex items-center border rounded-md">
                <button onClick={decreaseQuantity} className="px-3 py-2 text-gray-600 hover:text-orange-500">
                  <Minus className="h-4 w-4" />
                </button>
                <span className="px-4 py-2 text-center w-12">{quantity}</span>
                <button onClick={increaseQuantity} className="px-3 py-2 text-gray-600 hover:text-orange-500">
                  <Plus className="h-4 w-4" />
                </button>
              </div>

              {/* Product Comparison */}
              <ProductComparison initialProducts={[product]} />
            </div>
          </div>

          <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4 pt-6">
            <Button onClick={handleAddToCart} className="flex-1 bg-orange-500 hover:bg-orange-600">
              <ShoppingCart className="h-5 w-5 mr-2" />
              Tambah ke Keranjang
            </Button>
            <Button variant="outline" className="flex-1 border-orange-500 text-orange-500 hover:bg-orange-50">
              <Heart className="h-5 w-5 mr-2" />
              Tambah ke Wishlist
            </Button>
          </div>

          <div className="pt-6 border-t border-gray-200 space-y-4">
            <div className="flex items-start">
              <div className="w-8 h-8 rounded-full bg-orange-100 flex items-center justify-center mr-3">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-4 w-4 text-orange-500"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <div>
                <h4 className="font-medium text-gray-700">Bahan Berkualitas</h4>
                <p className="text-sm text-gray-500">Dibuat dengan bahan-bahan pilihan berkualitas tinggi</p>
              </div>
            </div>

            <div className="flex items-start">
              <div className="w-8 h-8 rounded-full bg-orange-100 flex items-center justify-center mr-3">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-4 w-4 text-orange-500"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
              </div>
              <div>
                <h4 className="font-medium text-gray-700">Pre-Order</h4>
                <p className="text-sm text-gray-500">Dibuat fresh setelah pemesanan, siap dalam 1-2 hari</p>
              </div>
            </div>

            <div className="flex items-start">
              <div className="w-8 h-8 rounded-full bg-orange-100 flex items-center justify-center mr-3">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-4 w-4 text-orange-500"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3"
                  />
                </svg>
              </div>
              <div>
                <h4 className="font-medium text-gray-700">Kustomisasi</h4>
                <p className="text-sm text-gray-500">Tersedia opsi kustomisasi sesuai permintaan</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Product Information Tabs */}
      <div className="mt-16">
        <Tabs defaultValue="description">
          <TabsList className="w-full border-b justify-start">
            <TabsTrigger value="description" className="text-base">
              Deskripsi
            </TabsTrigger>
            <TabsTrigger value="information" className="text-base">
              Informasi
            </TabsTrigger>
            <TabsTrigger value="reviews" className="text-base">
              Ulasan
            </TabsTrigger>
          </TabsList>
          <TabsContent value="description" className="py-6">
            <div className="prose max-w-none">
              <p className="text-gray-700 leading-relaxed">{product.longDescription}</p>
            </div>
          </TabsContent>
          <TabsContent value="information" className="py-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-lg font-semibold mb-4 text-orange-800">Bahan</h3>
                <p className="text-gray-700">{product.ingredients}</p>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-4 text-orange-800">Informasi Produk</h3>
                <div className="space-y-2">
                  <div className="flex">
                    <span className="font-medium w-32">Berat</span>
                    <span className="text-gray-700">{product.weight}</span>
                  </div>
                  <div className="flex">
                    <span className="font-medium w-32">Dimensi</span>
                    <span className="text-gray-700">{product.dimensions}</span>
                  </div>
                  <div className="flex">
                    <span className="font-medium w-32">Penyimpanan</span>
                    <span className="text-gray-700">{product.storage}</span>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
          <TabsContent value="reviews" className="py-6">
            <div className="space-y-8">
              {product.reviews.map((review) => (
                <div key={review.id} className="border-b pb-6">
                  <div className="flex items-center mb-2">
                    <h4 className="font-medium mr-2">{review.name}</h4>
                    <span className="text-gray-500 text-sm">{review.date}</span>
                  </div>
                  <div className="flex mb-2">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`h-4 w-4 ${i < review.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
                      />
                    ))}
                  </div>
                  <p className="text-gray-700">{review.comment}</p>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Related Products */}
      <div className="mt-16">
        <RelatedProducts currentProductId={product.id} category={product.category} />
      </div>

      {/* Recently Viewed Products */}
      <div className="mt-16">
        <RecentlyViewed currentProductId={product.id} />
      </div>
    </div>
  )
}

